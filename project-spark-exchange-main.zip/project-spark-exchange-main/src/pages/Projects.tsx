
import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Search, Filter, Download, Eye, IndianRupee } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Sample project data
const projectsData = [
  {
    id: 1,
    name: "AI-Based Attendance System",
    category: "Computer Science",
    technologies: ["Python", "OpenCV", "Flask", "SQLite"],
    description: "Facial recognition-based attendance system for classrooms with real-time detection and admin dashboard.",
    price: 1499,
    image: "/placeholder.svg",
    featured: true
  },
  {
    id: 2,
    name: "Smart Home Automation",
    category: "Electronics",
    technologies: ["Arduino", "IoT", "WiFi", "Sensors"],
    description: "Complete home automation system with mobile app control for lights, fans, and security.",
    price: 1299,
    image: "/placeholder.svg",
    featured: false
  },
  {
    id: 3,
    name: "E-Commerce Web Application",
    category: "Computer Science",
    technologies: ["React", "Node.js", "MongoDB", "Express"],
    description: "Full-stack e-commerce platform with payment integration, user authentication, and admin panel.",
    price: 1999,
    image: "/placeholder.svg",
    featured: true
  },
  {
    id: 4,
    name: "Voice-Controlled Robot",
    category: "Electronics",
    technologies: ["Raspberry Pi", "Python", "Speech Recognition"],
    description: "Voice-controlled robotic system capable of following commands and obstacle avoidance.",
    price: 1799,
    image: "/placeholder.svg",
    featured: false
  },
  {
    id: 5,
    name: "Student Management System",
    category: "Computer Science",
    technologies: ["Java", "MySQL", "Swing", "JDBC"],
    description: "Desktop application for managing student records, grades, and attendance with reporting features.",
    price: 999,
    image: "/placeholder.svg",
    featured: false
  },
  {
    id: 6,
    name: "Weather Monitoring Station",
    category: "Electronics",
    technologies: ["Arduino", "Sensors", "LCD", "Data Logging"],
    description: "Automated weather monitoring system with data logging and real-time display capabilities.",
    price: 899,
    image: "/placeholder.svg",
    featured: false
  }
];

const Projects = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceFilter, setPriceFilter] = useState("all");

  const filteredProjects = useMemo(() => {
    return projectsData.filter(project => {
      const matchesSearch = project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           project.technologies.some(tech => tech.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesCategory = selectedCategory === "all" || project.category === selectedCategory;
      
      const matchesPrice = priceFilter === "all" || 
                          (priceFilter === "under1000" && project.price < 1000) ||
                          (priceFilter === "1000to1500" && project.price >= 1000 && project.price <= 1500) ||
                          (priceFilter === "above1500" && project.price > 1500);

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [searchTerm, selectedCategory, priceFilter]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Student Projects
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover innovative projects crafted by talented students. Perfect for learning, academic submissions, and portfolio building.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                placeholder="Search projects or technologies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 py-3"
              />
            </div>

            {/* Category Filter */}
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Computer Science">Computer Science</SelectItem>
                <SelectItem value="Electronics">Electronics</SelectItem>
              </SelectContent>
            </Select>

            {/* Price Filter */}
            <Select value={priceFilter} onValueChange={setPriceFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Price Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Prices</SelectItem>
                <SelectItem value="under1000">Under ₹1,000</SelectItem>
                <SelectItem value="1000to1500">₹1,000 - ₹1,500</SelectItem>
                <SelectItem value="above1500">Above ₹1,500</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredProjects.length} of {projectsData.length} projects
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <Card key={project.id} className="group hover:shadow-xl transition-all duration-300 bg-white border-0 shadow-lg overflow-hidden">
              <CardHeader className="p-0">
                <div className="relative">
                  <img 
                    src={project.image} 
                    alt={project.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {project.featured && (
                    <Badge className="absolute top-4 left-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-0">
                      Featured
                    </Badge>
                  )}
                  <Badge className="absolute top-4 right-4 bg-white/90 text-gray-700">
                    {project.category}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="p-6">
                <CardTitle className="text-xl mb-3 group-hover:text-blue-600 transition-colors">
                  {project.name}
                </CardTitle>
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {project.description}
                </p>
                
                {/* Technologies */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech) => (
                    <Badge key={tech} variant="secondary" className="text-xs">
                      {tech}
                    </Badge>
                  ))}
                </div>
                
                {/* Price */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-2xl font-bold text-green-600">
                    <IndianRupee className="w-5 h-5" />
                    {project.price.toLocaleString()}
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="p-6 pt-0 flex gap-2">
                <Link to={`/projects/${project.id}`} className="flex-1">
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    <Eye className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </Link>
                <Button variant="outline" size="icon">
                  <Download className="w-4 h-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* No results */}
        {filteredProjects.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Filter className="w-16 h-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No projects found</h3>
            <p className="text-gray-500">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Projects;

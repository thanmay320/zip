
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Download, Mail, IndianRupee, Star, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

// Sample project data (in real app, this would come from API/database)
const projectsData = [
  {
    id: 1,
    name: "AI-Based Attendance System",
    category: "Computer Science",
    technologies: ["Python", "OpenCV", "Flask", "SQLite"],
    description: "Facial recognition-based attendance system for classrooms with real-time detection and admin dashboard.",
    fullDescription: "This comprehensive AI-based attendance system uses advanced facial recognition technology to automate the attendance process in educational institutions. The system captures real-time video, detects faces, recognizes students, and maintains accurate attendance records. Features include an intuitive admin dashboard, student management, attendance reports, and email notifications.",
    price: 1499,
    image: "/placeholder.svg",
    features: [
      "Real-time facial recognition",
      "Admin dashboard with analytics",
      "Student management system",
      "Automated attendance reports",
      "Email notification system",
      "SQLite database integration",
      "Web-based interface",
      "Export data to Excel/PDF"
    ],
    requirements: [
      "Python 3.7 or higher",
      "Webcam or IP camera",
      "Windows/Linux/MacOS",
      "4GB RAM minimum"
    ],
    modules: [
      "Face Detection Module",
      "Face Recognition Module",
      "Database Management",
      "Web Interface",
      "Report Generation",
      "Email Notification"
    ]
  },
  {
    id: 2,
    name: "Smart Home Automation",
    category: "Electronics",
    technologies: ["Arduino", "IoT", "WiFi", "Sensors"],
    description: "Complete home automation system with mobile app control for lights, fans, and security.",
    fullDescription: "A comprehensive smart home automation system that allows users to control various home appliances remotely through a mobile application. The system integrates multiple sensors, actuators, and IoT modules to create an intelligent home environment with features like automated lighting, climate control, security monitoring, and energy management.",
    price: 1299,
    image: "/placeholder.svg",
    features: [
      "Remote control via mobile app",
      "Voice command integration",
      "Motion detection sensors",
      "Temperature and humidity monitoring",
      "Automated lighting system",
      "Security alarm system",
      "Energy consumption tracking",
      "WiFi connectivity"
    ],
    requirements: [
      "Arduino Uno/ESP32",
      "WiFi connectivity",
      "Android/iOS device",
      "12V power supply"
    ],
    modules: [
      "Sensor Interface Module",
      "WiFi Communication Module",
      "Mobile App Interface",
      "Actuator Control Module",
      "Security Module",
      "Power Management"
    ]
  }
];

const ProjectDetails = () => {
  const { id } = useParams();
  const project = projectsData.find(p => p.id === parseInt(id || ""));

  if (!project) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Project Not Found</h1>
          <p className="text-gray-600 mb-8">The project you're looking for doesn't exist.</p>
          <Link to="/projects">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Projects
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link to="/projects">
            <Button variant="ghost" className="text-blue-600 hover:text-blue-700">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Projects
            </Button>
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Project Header */}
            <Card className="bg-white shadow-lg border-0">
              <CardContent className="p-0">
                <img 
                  src={project.image} 
                  alt={project.name}
                  className="w-full h-64 lg:h-80 object-cover rounded-t-lg"
                />
                <div className="p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <Badge className="bg-blue-100 text-blue-800">
                      {project.category}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm text-gray-600 ml-1">(5.0)</span>
                    </div>
                  </div>
                  <h1 className="text-4xl font-bold mb-4 text-gray-800">
                    {project.name}
                  </h1>
                  <p className="text-xl text-gray-600 mb-6">
                    {project.fullDescription}
                  </p>
                  
                  {/* Technologies */}
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold mb-3 text-gray-800">Technologies Used</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech) => (
                        <Badge key={tech} variant="secondary" className="px-3 py-1">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card className="bg-white shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Key Features</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-3">
                  {project.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Modules */}
            <Card className="bg-white shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Project Modules</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {project.modules.map((module, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold text-sm">
                          {index + 1}
                        </div>
                        <span className="font-medium text-gray-800">{module}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card className="bg-white shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">System Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {project.requirements.map((req, index) => (
                    <li key={index} className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-gray-700">{req}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Purchase Card */}
            <Card className="bg-gradient-to-br from-blue-600 to-purple-600 text-white shadow-xl border-0 sticky top-8">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center text-4xl font-bold mb-2">
                    <IndianRupee className="w-8 h-8" />
                    {project.price.toLocaleString()}
                  </div>
                  <p className="text-blue-100">Complete Project Package</p>
                </div>
                
                <Separator className="my-6 bg-white/20" />
                
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-300" />
                    <span>Complete source code</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-300" />
                    <span>Detailed documentation</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-300" />
                    <span>Installation guide</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <CheckCircle className="w-4 h-4 text-green-300" />
                    <span>Technical support</span>
                  </div>
                </div>
                
                <Separator className="my-6 bg-white/20" />
                
                <div className="space-y-3">
                  <Button className="w-full bg-white text-blue-600 hover:bg-gray-100 font-semibold py-3">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF Details
                  </Button>
                  <Link to="/contact" className="block">
                    <Button variant="outline" className="w-full border-white text-white hover:bg-white hover:text-blue-600 font-semibold py-3">
                      <Mail className="w-4 h-4 mr-2" />
                      Contact to Purchase
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Support Card */}
            <Card className="bg-white shadow-lg border-0">
              <CardHeader>
                <CardTitle className="text-lg text-gray-800">Need Help?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm mb-4">
                  Have questions about this project? Our team is here to help you succeed.
                </p>
                <Link to="/contact">
                  <Button variant="outline" className="w-full">
                    Get Support
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetails;
